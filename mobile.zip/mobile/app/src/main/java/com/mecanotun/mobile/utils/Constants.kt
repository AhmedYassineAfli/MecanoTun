package com.mecanotun.mobile.utils

object Constants {
    // API Base URL - Update this to your backend URL
    const val BASE_URL = "http://10.0.2.2:8080/api/" // For Android Emulator
    // const val BASE_URL = "http://localhost:8080/api/"  // For physical device, use your
    // computer's IP

    // Request Codes
    const val REQUEST_CODE_LOGIN = 1001
    const val REQUEST_CODE_SIGNUP = 1002

    // Intent Keys
    const val EXTRA_SERVICE_ID = "service_id"
    const val EXTRA_SERVICE_NAME = "service_name"
    const val EXTRA_APPOINTMENT_ID = "appointment_id"

    // Appointment Status
    const val STATUS_PENDING = "PENDING"
    const val STATUS_CONFIRMED = "CONFIRMED"
    const val STATUS_COMPLETED = "COMPLETED"
    const val STATUS_CANCELLED = "CANCELLED"
}
